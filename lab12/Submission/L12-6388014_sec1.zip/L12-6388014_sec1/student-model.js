/* Model: Connect to the Course JSON */
const studentJSON = require('../resources/data/student.json');
module.exports.studentJSON = studentJSON;
/* -------------------------- */
